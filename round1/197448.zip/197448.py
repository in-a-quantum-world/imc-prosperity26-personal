from datamodel import OrderDepth, TradingState, Order
from typing import Dict, List, Tuple, Optional
import jsonpickle


class Trader:
    """
    Version 9.1:

    PEPPER:
        Directional drift trader with target inventory schedule.
        Remains primary alpha source.

    OSMIUM:
        Moderate-aggression market maker with increased capacity and responsiveness:
            1. Trade only on strong signals and meaningful price edge to reduce noise & adverse selection
               (alpha threshold of 3 and constant take-edge of 1.5 seems good based on testing)
               (for some reason it does better on constant take-edge rather than a bunch of condition-based take-edges)
            2. Slightly simplified FV calculation (fv += 0.8 * imb)

    Philosophy unchanged:
        Pepper drives PnL
        Osmium contributes secondary alpha without dominating risk
    """

    LIMITS = {
        "INTARIAN_PEPPER_ROOT": 80,
        "ASH_COATED_OSMIUM": 80,
    }

    PEPPER_SOFT_LIMIT = 75
    OSMIUM_SOFT_LIMIT = 78

    PEPPER = "INTARIAN_PEPPER_ROOT"
    OSMIUM = "ASH_COATED_OSMIUM"

    DAY_LEN_EST = 1_000_000

    def run(self, state: TradingState):
        print(state.toJSON())
        data = self._load_data(state)
        self._handle_day_reset(state, data)

        result = {
            self.PEPPER: [],
            self.OSMIUM: [],
        }

        if self.PEPPER in state.order_depths:
            result[self.PEPPER] = self.trade_pepper(
                state, state.order_depths[self.PEPPER], data
            )

        if self.OSMIUM in state.order_depths:
            result[self.OSMIUM] = self.trade_osmium(
                state, state.order_depths[self.OSMIUM], data
            )

        traderData = jsonpickle.encode(data)

        return result, 0, traderData

    ########################################################
    # STATE MANAGEMENT
    ########################################################

    def _load_data(self, state):

        if getattr(state, "traderData", None):

            try:

                data = jsonpickle.decode(state.traderData)

                if isinstance(data, dict):

                    data.setdefault("last_timestamp", None)
                    data.setdefault("osmium_short_ema", None)
                    data.setdefault("osmium_long_ema", None)
                    data.setdefault("osmium_last_imbalance", 0.0)
                    data.setdefault("osmium_mid_hist", [])
                    data.setdefault("osmium_last_spread", None)

                    return data

            except Exception:
                pass

        return {
            "last_timestamp": None,
            "osmium_short_ema": None,
            "osmium_long_ema": None,
            "osmium_last_imbalance": 0.0,
            "osmium_mid_hist": [],
            "osmium_last_spread": None,
        }

    def _handle_day_reset(self, state, data):

        last_ts = data.get("last_timestamp")

        if last_ts is not None and state.timestamp < last_ts:

            data["osmium_short_ema"] = None
            data["osmium_long_ema"] = None
            data["osmium_last_imbalance"] = 0.0
            data["osmium_mid_hist"] = []
            data["osmium_last_spread"] = None

        data["last_timestamp"] = state.timestamp

    ########################################################
    # HELPERS
    ########################################################

    def _position(self, state, product):

        return state.position.get(product, 0)

    def _sorted_book(self, order_depth):

        bids = sorted(order_depth.buy_orders.items(), reverse=True)
        asks = sorted(order_depth.sell_orders.items())

        return bids, asks

    def _best_bid_ask(self, order_depth):

        bids, asks = self._sorted_book(order_depth)

        best_bid = bids[0][0] if bids else None
        best_ask = asks[0][0] if asks else None

        bid_vol = bids[0][1] if bids else 0
        ask_vol = -asks[0][1] if asks else 0

        return best_bid, best_ask, bid_vol, ask_vol

    def _mid(self, order_depth):

        best_bid, best_ask, _, _ = self._best_bid_ask(order_depth)

        if best_bid and best_ask:
            return (best_bid + best_ask) / 2

        if best_bid:
            return float(best_bid)

        if best_ask:
            return float(best_ask)

        return None

    def _microprice(self, order_depth):

        best_bid, best_ask, bid_vol, ask_vol = self._best_bid_ask(order_depth)

        if best_bid is None or best_ask is None:
            return self._mid(order_depth)

        total = bid_vol + ask_vol

        if total <= 0:
            return (best_bid + best_ask) / 2

        return (best_ask * bid_vol + best_bid * ask_vol) / total

    def _spread(self, order_depth):

        best_bid, best_ask, _, _ = self._best_bid_ask(order_depth)

        if best_bid is None or best_ask is None:
            return None

        return best_ask - best_bid

    def _imbalance(self, order_depth):

        _, _, bid_vol, ask_vol = self._best_bid_ask(order_depth)

        denom = bid_vol + ask_vol

        if denom <= 0:
            return 0.0

        return (bid_vol - ask_vol) / denom

    def _update_ema(self, prev, x, alpha):

        if prev is None:
            return x

        return alpha * x + (1 - alpha) * prev

    def _append_hist(self, xs, x, cap=60):

        xs.append(x)

        if len(xs) > cap:
            del xs[0]

    def _add_buy(self, orders: List[Order], product: str, price: int, qty: int, pos: int, limit: int) -> int:
        if qty <= 0:
            return pos
        qty = min(qty, limit - pos)
        if qty > 0:
            orders.append(Order(product, int(price), int(qty)))
            pos += qty
        return pos

    def _add_sell(self, orders: List[Order], product: str, price: int, qty: int, pos: int, limit: int) -> int:
        if qty <= 0:
            return pos
        qty = min(qty, limit + pos)
        if qty > 0:
            orders.append(Order(product, int(price), int(-qty)))
            pos -= qty
        return pos

    def _mean_std(self, xs):

        if not xs:
            return 0, 1

        n = len(xs)

        mu = sum(xs) / n

        var = sum((x - mu) ** 2 for x in xs) / max(1, n)

        std = var ** 0.5

        return mu, max(std, 1e-6)

    ########################################################
    # PEPPER STRATEGY (UNCHANGED)
    ########################################################

    def _pepper_fair_value(self, state: TradingState, order_depth: OrderDepth) -> float:
        """
        Snap fair value immediately each day; no laggy EMA anchor.
        Claude / your teammate's pattern:
            FV ~= 10000 + 1000*(day + 2) + 0.001 * timestamp
        In live simulation, infer day anchor directly from book.
        """
        mid = self._mid(order_depth)
        if mid is None:
            return 0.0

        raw_anchor = mid - 0.001 * state.timestamp
        anchor = 1000 * round(raw_anchor / 1000.0)
        return anchor + 0.001 * state.timestamp

    def _pepper_target_position(self, state: TradingState) -> int:
        """
        Aggressive long early, stay long most of day, reduce only late.
        """
        t = state.timestamp

        if t < 80_000:
            return 80
        if t < 700_000:
            return 72
        if t < 900_000:
            return 50
        return 40

    def trade_pepper(self, state: TradingState, order_depth: OrderDepth, data: Dict) -> List[Order]:
        product = self.PEPPER
        limit = self.LIMITS[product]
        soft_limit = self.PEPPER_SOFT_LIMIT
        pos = self._position(state, product)

        best_bid, best_ask, _, _ = self._best_bid_ask(order_depth)
        mid = self._mid(order_depth)
        spread = self._spread(order_depth)
        micro = self._microprice(order_depth)
        imb = self._imbalance(order_depth)

        if best_bid is None or best_ask is None or mid is None:
            return []

        fv = self._pepper_fair_value(state, order_depth)

        # Small microstructure adjustment, but drift dominates.
        fv += 0.35 * ((micro - mid) if micro is not None else 0.0)
        fv += 1.0 * imb

        target = self._pepper_target_position(state)
        gap = target - pos

        orders: List[Order] = []

        asks = sorted(order_depth.sell_orders.items())
        bids = sorted(order_depth.buy_orders.items(), reverse=True)

        # 1) Aggressively lift offers when below target.
        # Allow paying a few ticks above FV because the drift is the main edge.
        # PRIORITY 1 & 2 FIX: Use helper function and respect soft limits
        if gap > 0 and pos < soft_limit:  # Don't buy if at soft limit
            if gap > 50:
                cross_edge = 3.0
            elif gap > 25:
                cross_edge = 2.0
            else:
                cross_edge = 1.0

            remaining = min(gap, soft_limit - pos)  # Respect soft limit
            for ask_price, ask_qty_signed in asks:
                ask_qty = -ask_qty_signed
                if remaining <= 0:
                    break
                if ask_price <= fv + cross_edge:
                    take = min(ask_qty, remaining)
                    if take > 0:
                        # PRIORITY 1 FIX: Use helper function which checks limits
                        pos = self._add_buy(orders, product, ask_price, take, pos, limit)
                        remaining -= take
                else:
                    break

        # recompute gap after crossing
        gap = target - pos

        # 2) Directional passive quoting.
        # Buy-side strong, sell-side token unless above target or very rich.
        buy_price = min(best_bid + (1 if spread is not None and spread >= 2 else 0), int(round(fv - 1)))
        if buy_price >= best_ask:
            buy_price = best_ask - 1

        if gap > 40:
            buy_size = 24
        elif gap > 20:
            buy_size = 16
        elif gap > 5:
            buy_size = 10
        else:
            buy_size = 4

        # Only meaningful selling if above target or clearly rich vs FV.
        rich = best_bid - fv
        if pos > target + 10 or rich >= 3:
            ask_price = max(best_bid + 1, min(best_ask, int(round(fv + 2))))
            sell_size = 12 if pos > target + 20 else 6
        else:
            ask_price = max(best_ask, int(round(fv + 5)))
            sell_size = 10 if pos > 50 else (6 if pos > 40 else 0)

        # inventory safety
        if pos > 75:
            buy_size = 0
            sell_size = max(sell_size, 8)
            ask_price = best_bid + 1
        elif pos < 0:
            buy_size += 10

        pos = self._add_buy(orders, product, buy_price, buy_size, pos, limit)
        pos = self._add_sell(orders, product, ask_price, sell_size, pos, limit)

        return orders

    ########################################################
    # OSMIUM STRATEGY (UPGRADED)
    ########################################################

    def trade_osmium(self, state, order_depth, data):

        product = self.OSMIUM
        hard_limit = self.LIMITS[product]
        soft_limit = self.OSMIUM_SOFT_LIMIT
        pos = self._position(state, product)
        best_bid, best_ask, _, _ = self._best_bid_ask(order_depth)
        mid = self._mid(order_depth)
        spread = self._spread(order_depth)
        micro = self._microprice(order_depth)
        imb = self._imbalance(order_depth)

        if None in (best_bid, best_ask, mid, spread):
            return []

        short_ema = self._update_ema(data.get("osmium_short_ema"), mid, 0.10)
        long_ema = self._update_ema(data.get("osmium_long_ema"), mid, 0.03)
        data["osmium_short_ema"] = short_ema
        data["osmium_long_ema"] = long_ema
        self._append_hist(data["osmium_mid_hist"], mid)
        hist = data["osmium_mid_hist"]
        mu, sigma = self._mean_std(hist[-30:] if len(hist) >= 10 else hist)
        z = (mid - mu) / sigma if sigma > 0 else 0
        last_imb = data.get("osmium_last_imbalance", 0)
        imb_change = imb - last_imb
        data["osmium_last_imbalance"] = imb
        # last_spread = data.get("osmium_last_spread")
        # spread_change = spread - last_spread if last_spread else 0
        data["osmium_last_spread"] = spread

        ####################################################
        # FAIR VALUE MODEL (STRONGER SIGNAL RESPONSE)
        ####################################################

        fv = 10000

        fv += 0.70 * (short_ema - long_ema)

        fv += 0.8 * imb
        # fv += 0.45 * (micro - mid)
        # fv += 0.65 * imb + 0.35 * imb_change

        fv += 0.05 * (10000 - mid)

        fv += -0.55 * z

        fv += -0.05 * pos

        ####################################################
        # SPREAD REGIME SETTINGS (MORE ACTIVE)
        ####################################################

        if spread >= 24:
            halfwidth = 4
            base_size = 6
            # take_edge = 1.2

        elif spread >= 18:
            halfwidth = 3
            base_size = 6
            # take_edge = 0.9

        else:
            halfwidth = 2
            base_size = 5
            # take_edge = 0.6

        ####################################################
        # HIGH VOL FILTER (UNCHANGED)
        ####################################################

        if abs(z) > 2:
            base_size = max(4, base_size - 3)
            # take_edge += 0.5

        ####################################################
        # GIFT TAKING (REDUCED OVER-CROSSING???)
        ####################################################

        orders = []
        signal = fv - mid

        TAKE_THRESHOLD = 3
        take_edge = 1.5

        # --- BUY ONLY on strong positive ---
        if signal > TAKE_THRESHOLD and pos < soft_limit:
            for ask_price, ask_qty_signed in sorted(order_depth.sell_orders.items()):
                ask_qty = -ask_qty_signed
                if ask_price<=fv-take_edge and mid<=fv:
                    take = min(ask_qty, 20, soft_limit-pos)
                    if take > 0:
                        orders.append(Order(product, int(ask_price), int(take)))
                        pos += take
                else:
                    break
        # --- SELL ONLY on strong negative ---
        if signal < -TAKE_THRESHOLD and pos > -soft_limit:
            for bid_price, bid_qty in sorted(order_depth.buy_orders.items(), reverse=True):
                if bid_price >= fv+take_edge and mid >= fv:
                    take = min(bid_qty, 20, soft_limit+pos)
                    if take > 0:
                        orders.append(Order(product, int(bid_price), int(-take)))
                        pos -= take
                else:
                    break

        ####################################################
        # PASSIVE QUOTES
        ####################################################

        improve_bid = 1 if signal > 0.5 and spread >= 2 else 0
        improve_ask = 1 if signal < -0.5 and spread >= 2 else 0
        bid_price = min(best_bid + improve_bid, round(fv - halfwidth))
        ask_price = max(best_ask - improve_ask, round(fv + halfwidth))

        buy_size = base_size
        sell_size = base_size

        ####################################################
        # SIGNAL SIZING RESPONSE
        ####################################################

        if signal > 0.5:

            buy_size += 5
            sell_size -= 4

        elif signal < -0.5:

            sell_size += 5
            buy_size -= 4

        ####################################################
        # INVENTORY CONTROL (SCALED FOR 75 LIMIT)
        ####################################################

        if pos > 60:

            buy_size = min(buy_size, 2)
            sell_size += 4

        elif pos < -60:

            sell_size = min(sell_size, 2)
            buy_size += 4

        ####################################################
        # FINAL LIMIT PROTECTION
        ####################################################

        buy_room = max(0, hard_limit - pos)

        sell_room = max(0, hard_limit + pos)

        buy_size = min(buy_size, buy_room)

        sell_size = min(sell_size, sell_room)

        if buy_size > 0:
            orders.append(Order(product, int(bid_price), int(buy_size)))

        if sell_size > 0:
            orders.append(Order(product, int(ask_price), int(-sell_size)))

        return orders